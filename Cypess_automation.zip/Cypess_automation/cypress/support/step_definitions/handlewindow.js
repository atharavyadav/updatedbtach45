import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor'
require('cypress-xpath');

Given('handle window',()=>{
   cy.visit("https://demoqa.com/browser-windows")
   cy.title().then((data)=>{
      cy.log("title1" , data)
   })
//    cy.xpath("//button[@ID='tabButton']").invoke('removeAttr','target').click()
//    cy.url().should('include',"https://demoqa.com/browser-windows")
//    cy.xpath("//h1[@id='sampleHeading']").then((data)=>{
//        cy.log("text" , data.text())
// })
   // Get window object
cy.window().then((win) => {
   // Replace window.open(url, target)-function with our own arrow function
   cy.stub(win, 'open', url => 
   {
     // change window location to be same as the popup url
     win.location.href = Cypress.config().baseUrl + url;
   }).as("popup") // alias it with popup, so we can wait refer it with @popup
 })
 
  
})


