import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor'
require('cypress-xpath');

Given('mousehover',()=>{
   cy.visit("https://www.browserstack.com/")
   cy.xpath("//button[@id='developers-dd-toggle']").trigger('mouseover')
   cy.xpath("//span[text()='Documentation']").click()
})


