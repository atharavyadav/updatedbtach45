import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor'
require('cypress-xpath');

Given('handle frame1',()=>{
    cy.visit("https://demo.guru99.com/test/guru99home/") 
    cy.xpath("//iframe[@id='a077aa5e']")
   .should('be.visible')
   .then(($iframe) => {
       const $body = $iframe.contents().find('body')   

       cy.wrap($body)
       .xpath("//img[@src='Jmeter720.png']")
       .click()
  
   })
                                                                                                                                                                                                                                                                                                                                                                                                                                                    
})
