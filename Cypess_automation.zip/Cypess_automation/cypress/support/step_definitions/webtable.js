import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor'
require('cypress-xpath');

Given('user fetches Company	Group	Prev Close and other stock data',()=>{
   cy.visit("https://demo.guru99.com/test/web-table-element.php")
})

