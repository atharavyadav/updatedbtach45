import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor'
require('cypress-xpath');

Given('user fetches Company	Group	Prev Close and other stock data',()=>{
   cy.visit("https://demo.guru99.com/test/web-table-element.php")
   cy.xpath("//table[@class='dataTable']//tr").then((length)=>{
    for (let i = 1; i < length.length; i++) {
      cy.xpath("//table[@class='dataTable']//tr["+i+"]//td").then((length2)=>{
         for (let j = 1; j < length2.length+1; j++) {
            cy.xpath("//table[@class='dataTable']//tr["+i+"]//td["+j+"]").then((text)=>{
               cy.log("my values are"+ text.text())
         })
         }
      })
    }
    
   })
   
})

