import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor'
require('cypress-xpath');

beforeEach(()=>{
    cy.fixture("logintestdata").then((data)=>{
        cy.loginUI(data.url)
    })
  
})
Given('user enters firstname,lastname,phonenumber for contact infomration',()=>{
    cy.fixture("logintestdata").then((data)=>{
        cy.EnterValues(data.firstnameXpath,data.firstname)
        cy.EnterValues(data.lastnamexpath,data.lastname)
        cy.xpath("//select[@name='country']").select('ANTARCTICA')
        cy.screenshot('drodown')
        cy.xpath("//input[@name='subt']").click()
    })
})

afterEach(()=>{
    if(this.currentScenario.result.status==='failed')
    {
        cy.screenshot(this.currentScenario.picle.name)
    }
})