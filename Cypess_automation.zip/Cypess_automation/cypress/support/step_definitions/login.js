import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor'
require('cypress-xpath');

Given('user enters firstname,lastname,phonenumber for contact infomration',()=>{
    cy.fixture("logintestdata").then((data)=>{
        cy.loginUI(data.url)
    })
    cy.fixture("logintestdata").then((data)=>{
        cy.EnterValues(data.firstnameXpath,data.firstname)
        cy.EnterValues(data.lastnamexpath,data.lastname)
        cy.xpath("//select[@name='country']").select('ANTARCTICA')
        cy.screenshot('drodown')
        cy.xpath("//input[@name='subt']").click()
    })
})

