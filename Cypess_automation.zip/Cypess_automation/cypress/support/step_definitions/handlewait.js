import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor'
require('cypress-xpath');

Given('handle wait',()=>{
   cy.visit("https://www.hyrtutorials.com/p/waits-demo.html#google_vignette")
   cy.xpath("//button[@id='btn1']").click()
   cy.xpath("(//input[@id='txt1'])[1]").should('be.visible').type("hay")
   cy.wait(3000)
})


