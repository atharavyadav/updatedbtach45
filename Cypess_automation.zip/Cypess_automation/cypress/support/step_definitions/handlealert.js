import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor'
require('cypress-xpath');

Given('handle alert',()=>{
   cy.visit("https://demo.guru99.com/test/delete_customer.php")
   cy.xpath("//input[@name='submit']").click()
   cy.on("window:alert",(text)=>{
      cy.log("my altert text " , text)
   })
         
})

