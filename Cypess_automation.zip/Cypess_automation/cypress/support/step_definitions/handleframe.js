import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor'
require('cypress-xpath');

Given('handle frame',()=>{
   cy.visit("https://demo.guru99.com/test/guru99home/")
   // cy.getIframeBody("a077aa5e").then((data)=>{
   //    cy.xpath("//img[@src='Jmeter720.png']").click()
   // }) 
   cy.xpath("//iframe[@id='a077aa5e']")
   .should('be.visible')
   .then(($iframe) => {
       const $body = $iframe.contents().find('body')   

       cy.wrap($body)
       .xpath("//img[@src='Jmeter720.png']")
       .click()
  
   })
})


