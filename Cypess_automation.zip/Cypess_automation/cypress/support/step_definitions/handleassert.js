import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor'
require('cypress-xpath');
import 'cypress-file-upload'

Given('handle assert',()=>{
cy.visit("https://www.tutorialspoint.com/selenium/practice/upload-download.php")
     cy.xpath("//input[@id='uploadFile']").attachFile('uploadtestdata.json')                                                                                                                                                                                                                                                                                                                                                                                                                                               
})
