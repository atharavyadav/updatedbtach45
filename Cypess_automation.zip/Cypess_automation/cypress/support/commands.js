// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
/// <reference types="cypress-xpath" />
import * as XLSX from 'xlsx'

Cypress.Commands.add('loginUI',(url)=>{
    cy.visit(url)
})

Cypress.Commands.add('EnterValues',(xpath,value)=>{
    cy.xpath(xpath).type(value)

})

Cypress.Commands.add('getIframeBody', (iframeSelector) => {
    return cy
      .get(iframeSelector)
      .its('0.contentDocument.body')
      .should('not.be.empty') // Ensure the body is not empty
      .then(cy.wrap);
  });
  
  Cypress.Commands.add('getNestedIframeBody', (outerIframeSelector, innerIframeSelector) => {
    return cy
      .getIframeBody(outerIframeSelector)
      .find(innerIframeSelector)
      .its('0.contentDocument.body')
      .should('not.be.empty') // Ensure the nested body is not empty
      .then(cy.wrap);
  });

  Cypress.Commands.add('readDataFromExcel',(excelpath)=>{
  
    const workbook = XLSX.read(excelpath);
    const sheetName = workbook.SheetNames[0]
    const worksheet = workbook.Sheets[sheetName]
    const data  = XLSX.utils.sheet_to_json(worksheet)
    return data;

  })


Cypress.Commands.add('readExcelFile', (filePath) => {
  return cy.task('readExcelFile', filePath);
});