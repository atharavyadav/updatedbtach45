const { defineConfig } = require("cypress");
const createBundler = require("@bahmutov/cypress-esbuild-preprocessor");
const preprocessor = require("@badeball/cypress-cucumber-preprocessor");
const createEsbuildPlugin = require("@badeball/cypress-cucumber-preprocessor/esbuild");
const path = require('path');
const XLSX = require('xlsx');
module.exports = defineConfig({
  e2e: {
    defaultCommandTimeout: 25000,
    setupNodeEvents(on, config) {

      on("file:preprocessor",
      createBundler({
        plugins: [createEsbuildPlugin.default(config)],
      }));

      on('task', {
        readExcelFile(filePath) {
          const absolutePath = path.resolve(__dirname, 'cypress/fixtures', filePath);
          const workbook = XLSX.readFile(absolutePath);
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const data = XLSX.utils.sheet_to_json(worksheet);
          return data;
        }
      });
      preprocessor.addCucumberPreprocessorPlugin(on, config);
      return config;
    },

    retries:{
      runMode:2,
      openMode:0
    },
	specPattern: "**/*.feature",
  },
  
    "reporter": "mochawesome",
    "reporterOptions": {
       "reportDir": "cypress/results",
       "overwrite": false,
       "html": false,
       "json": true
    },
    "reporter": "junit",
    "reporterOptions": {
       "mochaFile": "cypress/results/results.xml",
       "toConsole": true
    },
    "reporter": "junit",
   "reporterOptions": {
      "mochaFile": "cypress/results/results-[hash].xml",
      "toConsole": true
   },
  "video":true
  
})