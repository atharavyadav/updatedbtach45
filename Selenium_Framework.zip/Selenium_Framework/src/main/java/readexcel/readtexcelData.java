package readexcel;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Driver.resusable;
import readInputTestData.readerFile;


public class readtexcelData {

	public static String fetchtestdatafromexcel(int rownum, int  column) throws IOException {
		FileInputStream fs = new FileInputStream(resusable.excellocation);
		try (XSSFWorkbook wb = new XSSFWorkbook(fs)) {
			XSSFSheet sheet = wb.getSheet("testdata");
			String data =sheet.getRow(rownum).getCell(column).toString();
			return data;
		}
	
	}
	
}
