package seleniumActions;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import Driver.LaunchDriver;

public class takeScreenshotAction {

	public static void takescreenshot() throws IOException
	{
		TakesScreenshot take = (TakesScreenshot)LaunchDriver.driver;//.png
		File file = take.getScreenshotAs(OutputType.FILE);//file
		FileUtils.copyFile(file, new File("D:\\eclipse\\Selenium_Framework\\screenshot\\Drodown.png"));
	}
}
