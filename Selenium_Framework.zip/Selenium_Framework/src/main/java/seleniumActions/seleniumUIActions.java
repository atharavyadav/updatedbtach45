package seleniumActions;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import Driver.LaunchDriver;
import readInputTestData.readerFile;


public class seleniumUIActions  {

	public static void enterName() throws IOException {
		
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Gurru.Demosite.Emailaddress.input"))).sendKeys("neelam.@gmail.com");
	}
	
public static void username() throws IOException {
		
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Gurru.Demosite.EmailPassword.input"))).sendKeys("7497");
	}

public static void clicksignButton() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Gurru.Demosite.SubmitLogin.button"))).click();
}

public static void enterUserName() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.Information.Firstname.input"))).sendKeys("neelam.@gmail.com");
}
}
