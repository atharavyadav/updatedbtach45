package seleniumActions;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Driver.LaunchDriver;
import readInputTestData.readerFile;
import readexcel.readtexcelData;


public class seleniumUIActions  {

	public static void enterName() throws IOException {
		
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Gurru.Demosite.Emailaddress.input"))).sendKeys(readtexcelData.fetchtestdatafromexcel(1, 1));
	}
	
public static void username() throws IOException {
		
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Gurru.Demosite.EmailPassword.input"))).sendKeys(readtexcelData.fetchtestdatafromexcel(1, 3));
	}

public static void clicksignButton() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Gurru.Demosite.SubmitLogin.button"))).click();
}

public static void enterUserName() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.Information.Firstname.input"))).sendKeys("neelam.@gmail.com");
}

public static void ValidateDropdown() throws IOException {
	
	WebElement ele = LaunchDriver.driver.findElement(By.xpath("//select[@name='country']"));
	Select select = new Select(ele);
	select.selectByValue("BELIZE");
	
}

public static void handlealert() throws IOException {
	LaunchDriver.driver.findElement(By.xpath("//input[@name='submit']")).click();
	Alert obj = LaunchDriver.driver.switchTo().alert();
	String beforeAlert = obj.getText();
	System.out.println(beforeAlert);
	obj.accept();
	String afteralert = obj.getText();
	System.out.println(afteralert);
	
	
}

}
