package Driver;

public interface resusable {

	public static String url = "https://demo.guru99.com/test/login.html";
	public static String registerurl = "https://demo.guru99.com/test/newtours/register.php";
	public static String frameuRL = "https://demo.guru99.com/test/guru99home/";
	public static String alterurl="https://demo.guru99.com/test/delete_customer.php";
	public static String excellocation="D:\\eclipse\\Selenium_Framework\\src\\test\\resources\\testdata\\testdata.xlsx";
	public static String waiturl="https://www.hyrtutorials.com/p/waits-demo.html";
	public static String checkboxUrl="https://demo.guru99.com/test/radio.html";


}
