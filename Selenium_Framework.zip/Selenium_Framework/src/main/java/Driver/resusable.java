package Driver;

public interface resusable {

	public static String url = "https://demo.guru99.com/test/login.html";
	public static String registerurl = "https://demo.guru99.com/test/newtours/register.php";
	public static String alterurl="https://demo.guru99.com/test/delete_customer.php";
	public static String excellocation="D:\\eclipse\\Selenium_Framework\\src\\test\\resources\\testdata\\testdata.xlsx";
}
