package Driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LaunchDriver {
	public static WebDriver driver = new ChromeDriver();
	
	public static void readDriver(String path,String url) {
	System.setProperty("webdriver.chrome.driver", path);
	driver.get(url);
	
	}
	
	public static void maximizeBrowser() {
		
		driver.manage().window().maximize();
	}
	
	public static void closebrowser()
	{
		driver.close();
	}
	
	public static void quitBrowser()
	{
		driver.quit();
	}
	
	
}
