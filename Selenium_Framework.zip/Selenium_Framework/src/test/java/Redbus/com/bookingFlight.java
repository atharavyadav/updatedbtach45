package Redbus.com;

import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Driver.LaunchDriver;
import Driver.resusable;
import seleniumActions.seleniumUIActions;

public class bookingFlight{

  @BeforeMethod
  public static void launchur()
  {
	  LaunchDriver.readDriver("D:\\eclipse\\Selenium_Framework\\selenium_Driver\\chromedriver.exe", resusable.url);
  }
  
  
@Test		
public static void searchflighdata() throws IOException
{
	
	 LaunchDriver.maximizeBrowser();
	 seleniumUIActions.enterName();
	 seleniumUIActions.username();
	 seleniumUIActions.clicksignButton();

	 //LaunchDriver.closebrowser();
}

@Test		
public static void bookflight() throws IOException
{
	
	 LaunchDriver.maximizeBrowser();
	 seleniumUIActions.enterName();
	 seleniumUIActions.username();
	 seleniumUIActions.clicksignButton();

	 //LaunchDriver.closebrowser();
}
	
	

}
