package Redbus.com;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Driver.LaunchDriver;
import Driver.resusable;
import seleniumActions.seleniumUIActions;
import seleniumActions.takeScreenshotAction;

public class handlealtertTC {
	@BeforeMethod
	  public static void launchur()
	  {
		  LaunchDriver.readDriver("D:\\eclipse\\Selenium_Framework\\selenium_Driver\\chromedriver.exe", resusable.alterurl);
	  }
	
	  
	@Test		
	public static void handlingalert() throws IOException
	{
		seleniumUIActions.handlealert();
		
	}
	@AfterMethod
	  public static void closebrowser()
	  {
		 LaunchDriver.driver.close();
	  }
}
