package Redbus.com;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Driver.LaunchDriver;
import Driver.resusable;
import seleniumActions.seleniumUIActions;

public class waitDemo {
	@BeforeMethod
	  public static void launchur()
	  {
		  LaunchDriver.readDriver("D:\\eclipse\\Selenium_Framework\\selenium_Driver\\chromedriver.exe", resusable.checkboxUrl);
	      LaunchDriver.driver.manage().window().maximize();
	  }
	
	  
	@Test		
	public static void handlewait() throws IOException, InterruptedException
	{
		seleniumUIActions.handlewait();
		
	}
	@AfterMethod
	  public static void closebrowser() throws InterruptedException
	  {
		Thread.sleep(5000);
		 LaunchDriver.driver.close();
	  }
}
