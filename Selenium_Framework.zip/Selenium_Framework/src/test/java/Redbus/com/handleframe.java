package Redbus.com;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import Driver.LaunchDriver;
import Driver.resusable;
import seleniumActions.seleniumUIActions;
import seleniumActions.takeScreenshotAction;

public class handleframe {
	private static Logger logger = LogManager.getLogger(handleframe.class);
	@BeforeMethod
	  public static void launchur()
	  {
		  logger.info("executioin strted and my url is"+resusable.frameuRL );
		  LaunchDriver.readDriver("D:\\eclipse\\Selenium_Framework\\selenium_Driver\\chromedriver.exe", resusable.frameuRL);
	  }
	
	  
	@Test		
	public static void handleframe() throws IOException
	{
		logger.info("handling frame" );
		seleniumUIActions.handleframe();
		logger.info("handling frame is successfull" );
		
	}
	@AfterMethod
	  public static void closebrowser()
	  {
		 LaunchDriver.driver.close();
	  }
}
