package Redbus.com;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Driver.LaunchDriver;
import Driver.resusable;
import seleniumActions.seleniumUIActions;
import seleniumActions.takeScreenshotAction;

public class SelectValues {
	@BeforeMethod
	  public static void launchur()
	  {
		  LaunchDriver.readDriver("D:\\eclipse\\Selenium_Framework\\selenium_Driver\\chromedriver.exe", resusable.registerurl);
	  }
	
	  
	@Test		
	public static void selectingDropdown() throws IOException
	{
		seleniumUIActions.ValidateDropdown();
		takeScreenshotAction.takescreenshot();
		
	}
	@AfterMethod
	  public static void closebrowser()
	  {
		 LaunchDriver.driver.close();
	  }
	
}
